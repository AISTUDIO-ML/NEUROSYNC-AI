import requests
import time

url_text = "http://localhost:8000/thought-to-text"
url_emotion = "http://localhost:8000/detect-emotion"

sample_data = {
    "eeg_data": {
        "delta": 0.5,
        "theta": 0.3,
        "alpha": 0.7,
        "beta": 0.6,
        "gamma": 0.4
    }
}

while True:
    try:
        r1 = requests.post(url_text, json=sample_data)
        r2 = requests.post(url_emotion, json=sample_data)
        print("Thought-to-Text:", r1.json())
        print("Emotion Detection:", r2.json())
    except Exception as e:
        print("Error:", e)
    time.sleep(5)
