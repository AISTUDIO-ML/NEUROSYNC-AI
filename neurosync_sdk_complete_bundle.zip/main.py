from fastapi import FastAPI, Request
from pydantic import BaseModel

app = FastAPI()

class EEGData(BaseModel):
    eeg_data: dict

@app.get("/")
def read_root():
    return {"message": "Welcome to NeuroSync AI SDK"}

@app.post("/thought-to-text")
def thought_to_text(data: EEGData):
    # Simulate thought-to-text conversion
    text = "Generated text based on EEG data"
    return {"text": text, "input": data.eeg_data}

@app.post("/detect-emotion")
def detect_emotion(data: EEGData):
    # Simulate emotion detection
    emotion = {"stress": 0.2, "focus": 0.8}
    return {"emotion": emotion, "input": data.eeg_data}
