import time
import requests

def generate_eeg_data():
    return {
        "delta": 0.5,
        "theta": 0.3,
        "alpha": 0.7,
        "beta": 0.6,
        "gamma": 0.4
    }

while True:
    eeg_data = {"eeg_data": generate_eeg_data()}
    try:
        r1 = requests.post("http://backend:8000/thought-to-text", json=eeg_data)
        r2 = requests.post("http://backend:8000/detect-emotion", json=eeg_data)
        print("Thought-to-text:", r1.json())
        print("Emotion detection:", r2.json())
    except Exception as e:
        print("Error:", e)
    time.sleep(5)
